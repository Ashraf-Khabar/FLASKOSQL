# FLASKOSQL
<center><img src="./source/flaskos.png"></center><br><br>
FLASKOS is a ORM for Oracle db for FLASK API, it provides a simple manupilation of database and simple mapiing to simplify interaction with relational database .
